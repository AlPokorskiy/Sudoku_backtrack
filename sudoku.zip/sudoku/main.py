# Made by Alex Pokorskiy
# Sudoku solver
# Description: Using the backtrack algorithm to solve a sudoku puzzle

board = [
    [7, 8, 0, 4, 0, 0, 1, 2, 0],
    [6, 0, 0, 0, 7, 5, 0, 0, 9],
    [0, 0, 0, 6, 0, 1, 0, 7, 8],
    [0, 0, 7, 0, 4, 0, 2, 6, 0],
    [0, 0, 1, 0, 5, 0, 9, 3, 0],
    [9, 0, 4, 0, 6, 0, 0, 0, 5],
    [0, 7, 0, 3, 0, 0, 0, 1, 2],
    [1, 2, 0, 0, 0, 7, 4, 0, 0],
    [0, 4, 9, 2, 0, 6, 0, 0, 7]
]


def print_board(bd):
    # this prints the sudoku board
    for i in range(len(bd)):
        if i % 3 == 0 and i != 0:  # for every 3 rows of items print out a line below the third row
            print('------------------------')
        for j in range(
                len(bd[0])):  # for every 3 items in a row print a horizontal slash | to devide number every 3 times
            if j % 3 == 0 and j != 0:
                print(' | ', end="")

            if j == 8:  # print the last item in the row
                print(bd[i][j])
            else:  # else print every item before j==8
                print(str(bd[i][j]) + " ", end="")


def find(bd):  # finding empty positions on the sudoku board
    for i in range(len(bd)):
        for j in range(len(bd[0])):  # range in length of each row
            if bd[i][j] == 0:  # check if the position is 0/empty
                return (i, j)  # return that position (row,column) as a tuple
    return None


def validate(bd, n, pos):
    # check if the board itself is a valid board/solvable board
    # takes the board = bd, the number = n, and using the position of the number = pos
    for i in range(len(bd[0])):
        if bd[pos[0]][i] == n and pos[1] != i:  # check that each column in that row to see if the number beside it is similar or not
            # and also make sure that the value does not match the position beside it
            return False

    for i in range(len(bd)):
        if bd[i][pos[1]] == n and pos[0] != i:  # check that each row in that column to see if the number beside it is similar or not
            # and also make sure that the value does not match the position beside it
            return False

    # check the 3x3 value bow that the values do not match
    box_x = pos[1] // 3
    box_y = pos[0] // 3

    for i in range(box_y * 3, box_y * +3):  # loop through each row inside a 3x3 box of values
        for j in range(box_x * 3, box_x * +3):  # loop every column inside the box
            if bd[i][j] == n and (i, j) != pos:  # if the
                return False

    return True


def solve(bd):
    fd = find(bd)
    if not fd:  # if no more empty positions found return True as in the board is solved.
        return True
    else:
        row, col = fd  # send the found empty space using the find() funtion
    for i in range(1, 10):  # basically just got from 1 to 9 generic loop
        if validate(bd, i, (row, col)):  # check if adding that value would create a valid solution
            bd[row][col] = i  # if it is valid the insert the value to that position

            if solve(bd):  # check if the board is solved
                return True

            bd[row][col] = 0  # reset the last value that we were not able to solve for

    # if after the loop there is no valid solution using the 1 to 10 loop then this will return false
    return False


print_board(board)
print("__________________________")
solve(board)
print("__________________________")
print_board(board)
